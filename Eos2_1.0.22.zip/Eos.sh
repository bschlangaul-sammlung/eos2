#! /bin/bash
javaw -jar Eos.jar